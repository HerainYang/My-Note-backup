package ghost;

import java.util.Objects;

public class Message {
    int X;
    int Y;
    int direction;
    Message target;

    public Message(int X, int Y, int direction, Message target){
        this.X = X;
        this.Y = Y;
        this.direction = direction;
        this.target = target;
    }

    @Override
    public boolean equals(Object o) {
        return (this.X == ((Message) o).X) && (this.Y == ((Message) o).Y);
    }
}

