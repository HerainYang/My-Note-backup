#define NUMBER 123*123
#define CHAR 'a'
#define STRING "string"
#define min(a, b) tellMin(a, b)
#define ISay(string) saySomething("I", string)



extern int count;
struct employee
{
    int ID;
    char* address;
    int phoneNumber;
};