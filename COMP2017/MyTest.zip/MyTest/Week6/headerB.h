
extern void saySomething(char* who, char* what){
    printf("%s say %s\n", who, what);
}