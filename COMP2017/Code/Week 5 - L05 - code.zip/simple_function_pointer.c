#include <stdio.h>

int main() {

	printf("function pointer: %p\n", main);

	return 0;

}

