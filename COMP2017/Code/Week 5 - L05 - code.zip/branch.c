int main() 
{
	int x = 33;
	if (x == 33) {
		x = 480+7;
	}
	x += 768;
	return 0;
}
