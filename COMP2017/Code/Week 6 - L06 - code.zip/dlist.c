/* dlist.c */

#include <stdio.h>

#include "dlist.h"

int dlist_size;


