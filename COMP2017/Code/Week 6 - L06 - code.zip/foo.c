/* foo.c */

// symbol for linker
const char* foo() {
	return "foo has finished.";
}
