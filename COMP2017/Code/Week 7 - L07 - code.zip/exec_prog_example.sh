#!/bin/bash

gcc -o exec_prog1 exec_prog1.c
gcc -o exec_prog2 exec_prog2.c
gcc -o exec_prog3 exec_prog3.c

echo "run the executable"
echo "example: "
echo "./exec_prog3 zee zoo zip!"
