#include <stdlib.h>
#include<stddef.h>

struct block{
    size_t size;
    int counter;
};

struct ref{
    struct block* memory;
    struct ref* children;
};

int memSize = 0;
struct block block[100000000];
int refSize = 0;
struct ref refs[100000000];

void* new_ref(size_t size, void* dep) {
  memSize++;
  block[memSize-1].size = size;
  block[memSize-1].counter++;
  refSize++;
  refs[refSize-1].memory = &block[memSize-1];
    return &block[memSize-1];
}

void* assign_ref(void* ref) {

  if(ref != NULL){
    refSize++;
    for(int i =0;i<refSize;i++){
      if(refs[i].memory == ref){
        refs[i].memory->size++;
      }
    }
  }
    return  ref;
}

void* del_ref(void* ref) {
  for(int i =0;i<refSize;i++){

    /* USYD CODE CITATION ACKNOWLEDGEMENT
	 * I declare that the following lines of code have been copied from the
     * tutorial solutions of Week 7 with only minor changes and it is not my own work. 
     * 
     * Tutorial solutions for week 7 from COMP2017 course
     * https://edstem.org/courses/1933
     */
    if(refs[i].memory == ref){
      refs[i].memory = NULL;
        refs[i].children = NULL;
        refSize--;
      return NULL;
    }
    /* end of copied code */
    
  }
    return NULL;
}

