#include <stdlib.h>
#include<stddef.h>

struct block{
	size_t size;
	int counter;
};

struct ref{
	struct block* memory;
	struct ref* children;
};

int memSize = 0;
struct block block[100000000];
int refSize = 0;
struct ref refs[100000000];

void* new_ref(size_t size, void* dep) {
  memSize++;
  block[memSize-1].size = size;
  block[memSize-1].counter++;
  refSize++;
  refs[refSize-1].memory = &block[memSize-1];
	return &block[memSize-1];
}


/* USYD CODE CITATION ACKNOWLEDGEMENT
 * I declare that the majority of the following function has been taken from the
 * website titled: "How to write a memory allocator" and it is not my own work. 
 * 
 * Original URL
 * https://allaboutc.org/how-to-write-a-memory-allocator.html
 * Last access April, 2018
 */
void* assign_ref(void* ref) {

  if(ref != NULL){
    refSize++;
    for(int i =0;i<refSize;i++){
      if(refs[i].memory == ref){
        refs[i].memory->size++;
      }
    }
  }
	return  ref;
}

void* del_ref(void* ref) {
  for(int i =0;i<refSize;i++){
    if(refs[i].memory == ref){
      refs[i].memory = NULL;
		refs[i].children = NULL;
		refSize--;
      return NULL;
    }
  }
	return NULL;
}

